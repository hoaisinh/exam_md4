package com.example.cinemamng;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaMngApplicationTests {

    @Test
    void contextLoads() {
    }

}
