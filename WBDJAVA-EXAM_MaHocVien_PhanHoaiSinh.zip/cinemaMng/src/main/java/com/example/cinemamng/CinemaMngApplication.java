package com.example.cinemamng;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaMngApplication {

    public static void main(String[] args) {
        SpringApplication.run(CinemaMngApplication.class, args);
    }

}
